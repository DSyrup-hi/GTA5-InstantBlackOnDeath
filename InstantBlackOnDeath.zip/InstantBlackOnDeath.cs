using System;
using GTA;
using GTA.Native;

public class InstantBlackOnDeath : Script
{
    private bool wasDead = false;

    public InstantBlackOnDeath()
    {
        Tick += OnTick;
    }

    private void OnTick(object sender, EventArgs e)
    {
        Ped player = Game.Player.Character;

        if (player.IsDead || player.Health <= 0)
        {
            // Run ONCE immediately upon death to prevent thread overload/crashes
            if (!wasDead)
            {
                // Instant screen fade out (0 milliseconds)
                Function.Call(Hash.DO_SCREEN_FADE_OUT, 0);

                // Stop dynamic police music
                Function.Call(Hash.CANCEL_MUSIC_EVENT, "GLOBAL_KILL_MUSIC");
                Function.Call(Hash.SET_AUDIO_FLAG, "DisableFlightMusic", true);

                wasDead = true;
            }

            // Continuously suppress HUD and post-fx overlays safely
            Function.Call(Hash.HIDE_HUD_AND_RADAR_THIS_FRAME);
            Function.Call(Hash.ANIMPOSTFX_STOP_ALL);
        }
        else
        {
            // Reset when alive again
            if (wasDead)
            {
                Function.Call(Hash.CLEAR_TIMECYCLE_MODIFIER);
                Function.Call(Hash.DO_SCREEN_FADE_IN, 500);
                wasDead = false;
            }
        }
    }
}